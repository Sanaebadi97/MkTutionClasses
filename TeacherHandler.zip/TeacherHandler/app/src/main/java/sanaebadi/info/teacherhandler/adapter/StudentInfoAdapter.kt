package sanaebadi.info.teacherhandler.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.stu_info_add_row.view.*
import sanaebadi.info.teacherhandler.R
import sanaebadi.info.teacherhandler.database.Student

class StudentInfoAdapter(private val context: Context) :
    RecyclerView.Adapter<StudentInfoAdapter.StudentInfoViewHolder>() {

    private var mStudentList: List<Student>? = null
    /*inflate layout*/
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentInfoViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.stu_info_add_row, parent, false)
        return StudentInfoViewHolder(view)
    }

    /*get list size*/
    override fun getItemCount(): Int {
        return if (mStudentList != null) mStudentList!!.size else 0
    }

    /*bind views*/
    override fun onBindViewHolder(holder: StudentInfoViewHolder, position: Int) {
        val student: Student = mStudentList!![position]
        holder.txtName.text = student.stu_name
        holder.txtStartDate.text = student.stu_starting_date
        holder.txtFeeDue.text = student.stu_fee_due
        holder.txtFeeDeposit.text = student.stu_fee_deposit
        holder.txtTestReport.text = student.stu_test_report
        holder.txtMobileNom.text = student.stu_mobil_nom
    }


    fun setStudentList(studentList: List<Student>) {
        mStudentList = studentList
        notifyDataSetChanged()
    }

    /*view holder class*/
    class StudentInfoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtName = view.txt_stu_name!!
        val txtStartDate = view.txt_stu_start_date!!
        val txtFeeDue = view.txt_stu_fee_due!!
        val txtFeeDeposit = view.txt_stu_fee_deposit!!
        val txtTestReport = view.txt_stu_test_report!!
        val txtMobileNom = view.txt_stu_phone_nom!!
    }
}