package sanaebadi.info.teacherhandler.activity

import android.content.Intent
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import sanaebadi.info.teacherhandler.R
import sanaebadi.info.teacherhandler.database.Student
import sanaebadi.info.teacherhandler.databinding.ActivityStudentInfoBinding
import sanaebadi.info.teacherhandler.viewModel.StudentViewModel


class StudentInfoActivity : BaseActivity() {
    private lateinit var binding: ActivityStudentInfoBinding
    private lateinit var studentViewModel: StudentViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_student_info)


        /*define edit text and get input string from there*/
        val stuName: String = binding.edtStudentName.text.toString()
        val stuStartDate: String = binding.edtStartingDate.text.toString()
        val stuFeeDue: String = binding.edtFeeDue.text.toString()
        val stuFeeDeposit: String = binding.edtFeeDeposit.text.toString()
        val stuTestReport: String = binding.edtTestReport.text.toString()
        val stuMobileNom: String = binding.edtMobileNumber.text.toString()

        /*on click on btn add and insert to list database*/
        binding.btnAddStudent.setOnClickListener {
            val student = Student(
                stuName, stuStartDate, stuFeeDue, stuFeeDeposit, stuTestReport,
                stuMobileNom
            )
            studentViewModel.insertStudent(student)

        }


        /*on click on btn show list to go to list activity*/
        binding.btnShowStudentList.setOnClickListener {
            val intent = Intent(this, StudentInfoListActivity::class.java)
            startActivity(intent)
        }
    }
}
