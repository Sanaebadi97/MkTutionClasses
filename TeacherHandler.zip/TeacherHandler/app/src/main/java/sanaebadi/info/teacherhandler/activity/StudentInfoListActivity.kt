package sanaebadi.info.teacherhandler.activity

import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import sanaebadi.info.teacherhandler.R
import sanaebadi.info.teacherhandler.adapter.StudentInfoAdapter
import sanaebadi.info.teacherhandler.databinding.ActivityStudentInfoListBinding
import sanaebadi.info.teacherhandler.viewModel.StudentViewModel

class StudentInfoListActivity : BaseActivity() {
    private lateinit var binding: ActivityStudentInfoListBinding
    private lateinit var rvStuInfo: RecyclerView
    private lateinit var stuAddAdapter: StudentInfoAdapter
    private lateinit var studentViewModel: StudentViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_student_info_list)

        rvStuInfo = binding.rvAddUserInfo
        stuAddAdapter = StudentInfoAdapter(this)
        studentViewModel = ViewModelProviders.of(this).get(StudentViewModel::class.java)
        studentViewModel.allStudentInfo.observe(this, Observer {
            stuAddAdapter.setStudentList(it)
        })
        initRecyclerView()
        rvStuInfo.adapter = stuAddAdapter


    }

    private fun initRecyclerView() {
        rvStuInfo.setHasFixedSize(true)
        rvStuInfo.layoutManager = LinearLayoutManager(
            this, RecyclerView.VERTICAL,
            false
        )
    }
}
